from playwright.async_api import async_playwright
import asyncio
import random


class SwiggySearchService:
    async def find_restaurant_url(self, restaurant_name: str, location: str) -> str:
        query = f"{restaurant_name} {location} swiggy"
        async with async_playwright() as p:
            max_retries = 3
            for attempt in range(max_retries):
                # Launch with stealth arguments
                browser = await p.chromium.launch(
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled"],
                )
                try:
                    # Use a realistic User Agent
                    context = await browser.new_context(
                        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                    )

                    # Add init script to remove webdriver property
                    await context.add_init_script("""
                        Object.defineProperty(navigator, 'webdriver', {
                            get: () => undefined
                        });
                    """)

                    page = await context.new_page()

                    await page.goto("https://www.google.com")

                    # Check for captcha immediately upon load
                    if await self._is_captcha_page(page):
                        print(f"Captcha detected on attempt {attempt + 1}. Retrying...")
                        await browser.close()
                        await asyncio.sleep(random.uniform(2.0, 4.0))
                        continue

                    # Human-like typing delay
                    await page.fill('textarea[name="q"]', query)
                    await asyncio.sleep(random.uniform(0.5, 1.5))  # Random delay

                    await page.press('textarea[name="q"]', "Enter")

                    # Using a slightly longer wait strategy to ensure results populate
                    try:
                        await page.wait_for_selector("#search", timeout=5000)
                    except Exception:
                        await page.wait_for_load_state("networkidle")

                    # Check for captcha after search
                    if await self._is_captcha_page(page):
                        print(
                            f"Captcha detected post-search on attempt {attempt + 1}. Retrying..."
                        )
                        await browser.close()
                        await asyncio.sleep(random.uniform(2.0, 4.0))
                        continue

                    # Handle "Not now" location popup if it appears
                    try:
                        not_now_btn = page.get_by_text("Not now")
                        if await not_now_btn.is_visible(timeout=3000):
                            await not_now_btn.click()
                            await asyncio.sleep(1)
                    except Exception:
                        pass

                    await asyncio.sleep(random.uniform(1.0, 2.0))

                    # Get all Swiggy restaurant/city links
                    links = await page.locator(
                        'a[href*="swiggy.com/restaurants"], a[href*="swiggy.com/city"]'
                    ).all()

                    if not links:
                        # Before giving up, double check if it's a captcha page that appeared late
                        if await self._is_captcha_page(page):
                            print(
                                f"Captcha detected (no links found) on attempt {attempt + 1}. Retrying..."
                            )
                            await browser.close()
                            await asyncio.sleep(random.uniform(2.0, 4.0))
                            continue

                        if attempt == max_retries - 1:
                            return "No Results Found"

                        # If no results but no captcha, assume it's just no results
                        return "No Results Found"

                    if links:
                        return await self._process_links(links, location, page)

                    if attempt == max_retries - 1:
                        return "No Results Found"

                except Exception as e:
                    print(f"Error checking attempt {attempt + 1}: {e}")
                    if attempt == max_retries - 1:
                        return f"Error: {str(e)}"
                finally:
                    try:
                        await browser.close()
                    except Exception:
                        pass

        return "Max Retries Exceeded"

    async def _is_captcha_page(self, page) -> bool:
        try:
            title = await page.title()
            if "sorry" in title.lower() or "robot" in title.lower():
                return True
            if await page.get_by_text("unusual traffic", exact=False).count() > 0:
                return True
            if await page.get_by_text("I'm not a robot", exact=False).count() > 0:
                return True
            return False
        except Exception:
            return False

    async def _process_links(self, links, location, page):
        normalized_target_location = location.lower().replace(" ", "")

        candidates = []
        for link in links:
            try:
                text = (await link.inner_text()).lower().replace("\n", " ")
                href = await link.get_attribute("href")
                is_restaurant_link = "/restaurants/" in href

                candidates.append(
                    {
                        "element": link,
                        "text": text,
                        "href": href,
                        "is_restaurant": is_restaurant_link,
                    }
                )
            except Exception:
                continue

        chosen_link = None
        for c in candidates:
            if c["is_restaurant"]:
                if (
                    normalized_target_location in c["text"].replace(" ", "")
                    or normalized_target_location in c["href"].replace("-", "").lower()
                ):
                    chosen_link = c["element"]
                    break

        if not chosen_link:
            for c in candidates:
                if c["is_restaurant"]:
                    chosen_link = c["element"]
                    break

        if not chosen_link:
            for c in candidates:
                if (
                    normalized_target_location in c["text"].replace(" ", "")
                    or normalized_target_location in c["href"].replace("-", "").lower()
                ):
                    chosen_link = c["element"]
                    break

        if not chosen_link and candidates:
            chosen_link = candidates[0]["element"]

        if not chosen_link:
            return "No Suitable Link Found"

        original_href = await chosen_link.get_attribute("href")

        final_url = original_href
        if "dineout" in original_href.lower():
            clean_href = (
                original_href.lower().replace("/dineout", "").replace("dineout/", "")
            )
            try:
                await page.goto(clean_href)
                await page.wait_for_load_state("networkidle")
                title = await page.title()
                is_404 = (
                    "Page Not Found" in title
                    or await page.get_by_text("Page Not Found", exact=False).count() > 0
                )
                if not is_404:
                    return page.url
            except Exception:
                pass

        if page.url != final_url:
            await page.goto(final_url)
            await page.wait_for_load_state("networkidle")

        if (
            "Page Not Found" in await page.title()
            or await page.get_by_text("Page Not Found", exact=False).count() > 0
        ):
            return "Page Not Found"

        return page.url
