import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    )
)

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.search_service import SwiggySearchService

router = APIRouter()
search_service = SwiggySearchService()


class SearchRequest(BaseModel):
    name: str
    location: str


from typing import Optional


class SearchResponse(BaseModel):
    url: Optional[str] = ""
    dineout_only: bool = False
    not_found: bool = False
    error: Optional[str] = None


@router.post("/search", response_model=SearchResponse)
async def search_restaurant(request: SearchRequest):
    result = await search_service.find_restaurant_url(request.name, request.location)

    response = SearchResponse()

    if (
        not result
        or "No Results" in result
        or "Page Not Found" in result
        or "No Suitable Link Found" in result
    ):
        response.not_found = True
        response.error = result if result else "Restaurant not found"
        return response

    if result.startswith("Error"):
        response.error = result
        # Treat technical errors as Not Found for user friendliness or keep as error?
        # User asked to "enable restaurant not found", usually implies business logic not found.
        # Let's keep technical error as error likely.
        raise HTTPException(status_code=500, detail=result)

    if "dineout" in result.lower():
        response.dineout_only = True

    response.url = result
    return response
