import asyncio
import sys
import os

# Add the project root to the python path to import app modules
sys.path.append(os.getcwd())

from app.services.search_service import SwiggySearchService


async def verify_search():
    service = SwiggySearchService()
    # Test with a known restaurant/location that should have results
    print("Starting search verification...")
    print("Searching for 'Pizza Hut' in 'Mumbai'...")

    result = await service.find_restaurant_url("Pizza Hut", "Mumbai")

    print(f"Search Result: {result}")

    if result and "swiggy.com" in result:
        print("✅ SUCCESS: Search returned a valid Swiggy URL.")
    else:
        print("❌ FAILURE: Search did not return a valid Swiggy URL.")


if __name__ == "__main__":
    asyncio.run(verify_search())
