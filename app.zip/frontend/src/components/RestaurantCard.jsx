import { motion } from 'framer-motion';
import { Star, MapPin, ExternalLink, Share2, Heart } from 'lucide-react';
import PromoList from './PromoList';
import MenuCarousel from './MenuCarousel';

const RestaurantCard = ({ data }) => {
    const { name, location, rating, total_ratings, promo_codes, items_99, url, dineout_only } = data;
    const ratingValue = parseFloat(rating);
    const isHighRating = ratingValue >= 4.0;

    return (
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full glass-card rounded-3xl overflow-hidden mb-8 group border-t-4 border-t-swiggy-orange"
        >
            <div className="flex flex-col md:flex-row">
                {/* Left Side: Avatar & Basic Info (Mobile heavy) */}
                <div className="p-6 md:p-8 flex-1 border-b md:border-b-0 md:border-r border-base-200/50">
                    <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-4">
                            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-swiggy-orange to-swiggy-lightOrange text-white flex items-center justify-center text-3xl font-display font-bold shadow-lg shadow-swiggy-orange/20">
                                {name.charAt(0)}
                            </div>
                            <div>
                                <h2 className="text-2xl font-bold font-display leading-tight flex items-center gap-2">
                                    {name}
                                    {dineout_only && <span className="badge badge-warning gap-1 text-xs">🍽️ Dineout Only</span>}
                                </h2>
                                <div className="flex items-center gap-1 text-base-content/60 mt-1">
                                    <MapPin size={14} />
                                    <span className="text-sm font-medium">{location}</span>
                                </div>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button className="btn btn-circle btn-ghost btn-sm hover:bg-red-50 hover:text-red-500 transition-colors tooltip tooltip-bottom" data-tip="Save">
                                <Heart size={18} />
                            </button>
                            <button className="btn btn-circle btn-ghost btn-sm transition-colors tooltip tooltip-bottom" data-tip="Share">
                                <Share2 size={18} />
                            </button>
                        </div>
                    </div>

                    <div className="mt-6 flex items-center gap-8">
                        <div className="flex flex-col gap-1">
                            <span className="text-xs uppercase font-bold text-base-content/40 tracking-wider">Rating</span>
                            <div className="flex items-center gap-2">
                                <div className={`badge ${isHighRating ? 'bg-accents-green border-accents-green' : 'bg-yellow-400 border-yellow-400'} text-white font-bold p-3 gap-1 shadow-md`}>
                                    <Star size={14} fill="currentColor" />
                                    {rating}
                                </div>
                                <span className="text-sm font-medium text-base-content/60">({total_ratings})</span>
                            </div>
                        </div>

                        <div className="flex flex-col gap-1 w-full max-w-[120px]">
                            <span className="text-xs uppercase font-bold text-base-content/40 tracking-wider">Quality</span>
                            {/* Fake Progress based on rating */}
                            <progress className={`progress ${isHighRating ? 'progress-success' : 'progress-warning'} w-full h-2`} value={ratingValue * 20} max="100"></progress>
                        </div>
                    </div>

                    <div className="mt-8">
                        <a
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="btn btn-outline w-full md:w-auto gap-2 rounded-xl group-hover:bg-base-content group-hover:text-base-100 transition-all font-bold"
                        >
                            View on Swiggy <ExternalLink size={16} />
                        </a>
                    </div>
                </div>

                {/* Right Side / Bottom: Details */}
                <div className="flex-[1.5] flex flex-col bg-base-50/50 dark:bg-base-200/10">
                    <div className="p-6 md:p-8 border-b border-base-200/50">
                        <MenuCarousel items={items_99} />
                    </div>
                    <div className="p-6 md:p-8 bg-white/40 dark:bg-black/5 flex-1">
                        <PromoList promos={promo_codes} />
                    </div>
                </div>
            </div>
        </motion.div>
    );
};

export default RestaurantCard;
