import { useRef } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, ChevronRight, ChevronLeft } from 'lucide-react';

const MenuCarousel = ({ items }) => {
    const scrollRef = useRef(null);

    const scroll = (direction) => {
        if (scrollRef.current) {
            const { current } = scrollRef;
            const scrollAmount = 300;
            if (direction === 'left') {
                current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
            } else {
                current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
            }
        }
    };

    if (!items || items.length === 0) return null;

    return (
        <div className="w-full relative group/carousel">
            <h3 className="text-lg font-bold flex items-center gap-2 mb-3 px-1">
                <ShoppingBag className="text-swiggy-lightPurple" size={20} />
                <span>99 Store Items</span>
                <span className="badge badge-secondary badge-outline text-xs font-normal">{items.length}</span>
            </h3>

            {/* Scroll Buttons */}
            <button
                onClick={() => scroll('left')}
                className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-white/90 dark:bg-black/50 rounded-full shadow-lg opacity-0 group-hover/carousel:opacity-100 transition-opacity -ml-4 border border-base-200"
            >
                <ChevronLeft size={20} />
            </button>
            <button
                onClick={() => scroll('right')}
                className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-white/90 dark:bg-black/50 rounded-full shadow-lg opacity-0 group-hover/carousel:opacity-100 transition-opacity -mr-4 border border-base-200"
            >
                <ChevronRight size={20} />
            </button>

            <div
                ref={scrollRef}
                className="flex gap-4 overflow-x-auto pb-4 pt-1 px-1 snap-x scrollbar-hide"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
                {items.map((item, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.05 }}
                        className="snap-start min-w-[160px] w-[160px] md:min-w-[180px] flex-shrink-0 bg-base-100 dark:bg-neutral rounded-xl p-3 border border-base-200 shadow-sm hover:shadow-md transition-all hover:-translate-y-1 flex flex-col items-center text-center gap-2"
                    >
                        {/* Placeholder Food Image */}
                        <div className="w-full aspect-square rounded-lg bg-gradient-to-br from-gray-100 to-gray-200 dark:from-white/5 dark:to-white/10 flex items-center justify-center text-3xl mb-1 relative overflow-hidden">
                            <span className="z-10">🍱</span>
                            <div className="absolute inset-0 bg-white/20 skew-x-12 -translate-x-full animate-[shimmer_2s_infinite]"></div>
                        </div>

                        <p className="font-medium text-sm line-clamp-2 leading-tight" title={item}>
                            {item}
                        </p>
                        <div className="mt-auto pt-2 w-full">
                            <button className="btn btn-xs btn-outline w-full rounded-lg text-[10px] h-7 min-h-0 uppercase">View</button>
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};

export default MenuCarousel;
