import asyncio
from app.services.extract_service import SwiggyExtractService

# Sample data provided by the user
sample_response = {
    "statusCode": 0,
    "data": {
        "statusMessage": "done successfully",
        "cards": [
            {
                "card": {
                    "card": {
                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Restaurant",
                        "info": {
                            "id": "20170",
                            "name": "The Plush",
                            "avgRatingString": "4.4",
                            "totalRatingsString": "15K+ ratings",
                        },
                    }
                }
            }
        ],
    },
}


async def test_service_extraction():
    print("Testing SwiggyExtractService.extract_ratings...")
    service = SwiggyExtractService()

    # Test the standalone method
    result = service.extract_ratings(sample_response["data"])
    print(f"Extraction Result: {result}")

    expected = {"avgRatingString": "4.4", "totalRatingsString": "15K+ ratings"}

    if result == expected:
        print("✅ SUCCESS: Service extraction matched expected values.")
    else:
        print(f"❌ FAILURE: Expected {expected}, got {result}")


if __name__ == "__main__":
    asyncio.run(test_service_extraction())
