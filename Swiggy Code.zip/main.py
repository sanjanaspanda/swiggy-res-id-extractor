
from playwright.sync_api import sync_playwright
import re

def do_search(query):
    with sync_playwright() as p:
        # Launch with stealth arguments
        browser = p.chromium.launch(
            headless=True,
            args=["--disable-blink-features=AutomationControlled"]
        )
        # Use a realistic User Agent
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        
        # Add init script to remove webdriver property
        context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
        """)
        
        page = context.new_page()
        page.goto("https://www.google.com")
        
        # Human-like typing delay
        import random
        import time
        
        page.fill('textarea[name="q"]', query)
        time.sleep(random.uniform(0.5, 1.5)) # Random delay
        
        page.press('textarea[name="q"]', "Enter")
        page.wait_for_load_state("networkidle")
        
        # Handle "Not now" location popup if it appears
        try:
            # Look for "Not now" text which is common for location prompts
            # Using a short timeout so we don't block if it doesn't appear
            not_now_btn = page.get_by_text("Not now") 
            if not_now_btn.is_visible(timeout=3000):
                not_now_btn.click()
                time.sleep(1) # Stability wait
        except Exception:
            pass
        
        # Random delay before clicking
        time.sleep(random.uniform(1.0, 2.0))
        
        # Click the first link that matches the Swiggy restaurant or city patterns
        page.locator('a[href*="swiggy.com/restaurants"], a[href*="swiggy.com/city"]').first.click()
        try:
            page.wait_for_load_state("networkidle")
        except Exception:
            return "Network Error"
        if "Page Not Found" in page.title() or page.get_by_text("Page Not Found", exact=False).count() > 0:
            return "Page Not Found"
        
        print(f"Result URL: {page.url}")
        return page.url

import csv
from concurrent.futures import ThreadPoolExecutor

def process_row(row):
    try:
        query = f"{row['Restaurant Name']} ({row['Location']}) swiggy"
        row['swiggy res id'] = do_search(query)
    except Exception as e:
        print(f"Error processing {row['Restaurant Name']}: {e}")
        row['swiggy res id'] = "Error"
    return row

def main():
    input_file = "restaurants.csv"
    output_file = "restaurants_with_ids.csv"
    
    rows = []
    with open(input_file, mode='r', encoding='utf-8') as f_in:
        reader = csv.DictReader(f_in)
        rows = list(reader)
        fieldnames = reader.fieldnames + ['swiggy res id']
    
    # Run in parallel with ThreadPoolExecutor
    # You can adjust max_workers based on your system capabilities
    processed_rows = []
    with ThreadPoolExecutor(max_workers=4) as executor:
        processed_rows = list(executor.map(process_row, rows))
        
    with open(output_file, mode='w', encoding='utf-8', newline='') as f_out:
        writer = csv.DictWriter(f_out, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(processed_rows)
        
    print(f"Done! Processed {len(processed_rows)} restaurants. Saved to {output_file}")
    return

if __name__ == "__main__":
    main()